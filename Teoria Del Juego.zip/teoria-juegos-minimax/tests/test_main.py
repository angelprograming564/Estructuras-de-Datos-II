"""Pruebas básicas para el ejemplo de Minimax. Ejecutar con unittest."""

import unittest

from main import (
    COMPUTADORA,
    HUMANO,
    crear_tablero,
    ganador,
    juego_terminado,
    mejor_jugada,
    movimientos_disponibles,
    poner_ficha,
)


class PruebasTresEnRaya(unittest.TestCase):
    def test_tablero_inicial(self):
        tablero = crear_tablero()
        self.assertEqual(len(tablero), 3)
        self.assertEqual(len(movimientos_disponibles(tablero)), 9)
        self.assertIsNone(ganador(tablero))

    def test_victoria_en_diagonal(self):
        tablero = crear_tablero()
        for posicion in (0, 4, 8):
            poner_ficha(tablero, posicion, HUMANO)
        self.assertEqual(ganador(tablero), HUMANO)
        self.assertTrue(juego_terminado(tablero))

    def test_computadora_encuentra_victoria_inmediata(self):
        tablero = [
            [COMPUTADORA, COMPUTADORA, " "],
            [HUMANO, HUMANO, " "],
            [" ", " ", " "],
        ]
        posicion, puntaje, estados = mejor_jugada(tablero)
        self.assertEqual(posicion, 2)
        self.assertEqual(puntaje, 1)
        self.assertGreater(estados, 0)

    def test_computadora_bloquea_rival(self):
        tablero = [
            [HUMANO, HUMANO, " "],
            [" ", COMPUTADORA, " "],
            [" ", " ", " "],
        ]
        posicion, _, _ = mejor_jugada(tablero)
        self.assertEqual(posicion, 2)

    def test_empate_con_juego_perfecto(self):
        tablero = crear_tablero()
        # X abre en una esquina. O puede forzar un empate.
        poner_ficha(tablero, 0, HUMANO)
        _, puntaje, _ = mejor_jugada(tablero)
        self.assertEqual(puntaje, 0)


if __name__ == "__main__":
    unittest.main()
