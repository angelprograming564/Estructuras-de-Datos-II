"""Tres en raya: un ejemplo de teoría de juegos con Minimax y poda alfa-beta.

Ejecuta: python main.py
No necesita librerías externas.
"""

from __future__ import annotations

from typing import Optional


Tablero = list[list[str]]
VACIO = " "
HUMANO = "X"       # Jugador que intenta minimizar la utilidad de la IA.
COMPUTADORA = "O"  # Jugador que intenta maximizar su utilidad.


ORDEN_POSICIONES = (4, 0, 2, 6, 8, 1, 3, 5, 7)


def crear_tablero() -> Tablero:
    """Crea un tablero vacío representado por una matriz 3 x 3."""
    return [[VACIO for _ in range(3)] for _ in range(3)]


def mostrar_tablero(tablero: Tablero) -> None:
    """Muestra las posiciones, usando 1 a 9 para las casillas vacías."""
    print()
    for fila in range(3):
        celdas = []
        for columna in range(3):
            contenido = tablero[fila][columna]
            numero = str(fila * 3 + columna + 1)
            celdas.append(contenido if contenido != VACIO else numero)
        print(" " + " | ".join(celdas))
        if fila < 2:
            print("---+---+---")
    print()


def movimientos_disponibles(tablero: Tablero) -> list[int]:
    """Devuelve los índices (0 a 8) de las casillas disponibles."""
    return [
        posicion
        for posicion in ORDEN_POSICIONES
        if tablero[posicion // 3][posicion % 3] == VACIO
    ]


def ganador(tablero: Tablero) -> Optional[str]:
    """Devuelve 'X', 'O' o None si todavía nadie ganó."""
    lineas = []
    lineas.extend(tablero)  # Tres filas.
    lineas.extend([[tablero[f][c] for f in range(3)] for c in range(3)])
    lineas.append([tablero[i][i] for i in range(3)])
    lineas.append([tablero[i][2 - i] for i in range(3)])

    for linea in lineas:
        if linea[0] != VACIO and linea[0] == linea[1] == linea[2]:
            return linea[0]
    return None


def juego_terminado(tablero: Tablero) -> bool:
    """Comprueba si hubo victoria o empate."""
    return ganador(tablero) is not None or not movimientos_disponibles(tablero)


def poner_ficha(tablero: Tablero, posicion: int, ficha: str) -> None:
    """Coloca temporalmente una ficha en una posición entre 0 y 8."""
    tablero[posicion // 3][posicion % 3] = ficha


def minimax(
    tablero: Tablero,
    turno_computadora: bool,
    alfa: int,
    beta: int,
    estadisticas: list[int],
) -> int:
    """Evalúa el árbol de decisiones usando Minimax y poda alfa-beta.

    +1: gana la computadora (O)
     0: empate
    -1: gana la persona (X)

    Las posiciones se modifican y deshacen (backtracking), evitando
    crear un tablero nuevo en cada nodo del árbol.
    """
    estadisticas[0] += 1  # Cantidad de estados evaluados.

    resultado = ganador(tablero)
    if resultado == COMPUTADORA:
        return 1
    if resultado == HUMANO:
        return -1
    if not movimientos_disponibles(tablero):
        return 0

    if turno_computadora:
        mejor_valor = -2  # Menor que la utilidad mínima posible (-1).
        for posicion in movimientos_disponibles(tablero):
            poner_ficha(tablero, posicion, COMPUTADORA)
            valor = minimax(tablero, False, alfa, beta, estadisticas)
            poner_ficha(tablero, posicion, VACIO)  # Deshacer jugada.
            mejor_valor = max(mejor_valor, valor)
            alfa = max(alfa, mejor_valor)
            if beta <= alfa:
                break  # No interesa explorar esta rama.
        return mejor_valor

    peor_valor = 2  # Mayor que la utilidad máxima posible (+1).
    for posicion in movimientos_disponibles(tablero):
        poner_ficha(tablero, posicion, HUMANO)
        valor = minimax(tablero, True, alfa, beta, estadisticas)
        poner_ficha(tablero, posicion, VACIO)  # Deshacer jugada.
        peor_valor = min(peor_valor, valor)
        beta = min(beta, peor_valor)
        if beta <= alfa:
            break
    return peor_valor


def mejor_jugada(tablero: Tablero) -> tuple[int, int, int]:
    """Devuelve (posición 0-8, puntaje previsto, estados evaluados)."""
    if juego_terminado(tablero):
        raise ValueError("No se puede jugar: la partida terminó.")

    mejor_posicion = -1
    mejor_valor = -2
    estadisticas = [0]

    for posicion in movimientos_disponibles(tablero):
        poner_ficha(tablero, posicion, COMPUTADORA)
        valor = minimax(tablero, False, -2, 2, estadisticas)
        poner_ficha(tablero, posicion, VACIO)

        if valor > mejor_valor:
            mejor_valor = valor
            mejor_posicion = posicion

    return mejor_posicion, mejor_valor, estadisticas[0]


def pedir_jugada(tablero: Tablero) -> int:
    """Solicita al usuario una casilla válida del 1 al 9."""
    while True:
        try:
            entrada = input("Tu turno (elige una casilla del 1 al 9): ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nPartida interrumpida. ¡Hasta luego!")
            raise SystemExit(0) from None

        if not entrada.isdigit() or not 1 <= int(entrada) <= 9:
            print("Escribe un número entero entre 1 y 9.")
            continue

        posicion = int(entrada) - 1
        if posicion not in movimientos_disponibles(tablero):
            print("Esa casilla está ocupada. Elige otra.")
            continue
        return posicion


def jugar() -> None:
    """Ejecuta una partida completa contra la inteligencia artificial."""
    tablero = crear_tablero()
    print("=" * 45)
    print("   TEORÍA DE JUEGOS: MINIMAX EN ACCIÓN")
    print("=" * 45)
    print("Tú juegas con X y comienzas. La computadora usa O.")
    print("La computadora anticipa posibles jugadas con Minimax.")

    while not juego_terminado(tablero):
        mostrar_tablero(tablero)
        poner_ficha(tablero, pedir_jugada(tablero), HUMANO)

        if juego_terminado(tablero):
            break

        posicion, puntaje, estados = mejor_jugada(tablero)
        poner_ficha(tablero, posicion, COMPUTADORA)
        print(f"\nComputadora elige la casilla {posicion + 1}.")
        print(f"Estados analizados: {estados}. Valor previsto: {puntaje:+d}.")

    mostrar_tablero(tablero)
    resultado = ganador(tablero)
    if resultado == HUMANO:
        print("¡Ganaste! (Esto no debería pasar si la IA juega óptimamente.)")
    elif resultado == COMPUTADORA:
        print("Ganó la computadora.")
    else:
        print("¡Empate! Ambos jugaron bien.")
    print("Valores: +1 = gana IA, 0 = empate, -1 = gana humano.")


if __name__ == "__main__":
    jugar()
