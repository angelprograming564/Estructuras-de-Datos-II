package com.mycompany.arbolesexpresion;

import java.util.Scanner;

public class ArbolesExpresion {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.println("=================================");
        System.out.println("   ÁRBOLES DE EXPRESIÓN");
        System.out.println("=================================");
        System.out.println();

        System.out.print("Ingrese una expresión infija: ");
        String infija = sc.nextLine();

        String posfija = ConversorNotacion.infijaAPosfija(infija);
        String prefija = ConversorNotacion.infijaAPrefija(infija);

        System.out.println();
        System.out.println("Expresión infija:  " + infija);
        System.out.println("Expresión posfija: " + posfija);
        System.out.println("Expresión prefija: " + prefija);

        NodoExpresion raiz =
                ConstructorArbol.construirDesdePosfija(posfija);

        StringBuilder preorden = new StringBuilder();
        StringBuilder inorden = new StringBuilder();
        StringBuilder postorden = new StringBuilder();

        Recorridos.preorden(raiz, preorden);
        Recorridos.inorden(raiz, inorden);
        Recorridos.postorden(raiz, postorden);

        System.out.println();
        System.out.println("RECORRIDOS DEL ÁRBOL");
        System.out.println("---------------------");
        System.out.println("Preorden:  " + preorden.toString().trim());
        System.out.println("Inorden:   " + inorden.toString().trim());
        System.out.println("Postorden: " + postorden.toString().trim());

        double resultadoPosfija =
                EvaluadorExpresiones.evaluarPosfija(posfija);

        double resultadoPrefija =
                EvaluadorExpresiones.evaluarPrefija(prefija);

        System.out.println();
        System.out.println("EVALUACIÓN");
        System.out.println("---------------------");
        System.out.println("Resultado posfija: " + resultadoPosfija);
        System.out.println("Resultado prefija: " + resultadoPrefija);

        if (resultadoPosfija == resultadoPrefija) {
            System.out.println("Los resultados coinciden.");
        }

        System.out.println();
        System.out.println("INFORMACIÓN DEL ÁRBOL");
        System.out.println("---------------------");
        System.out.println("Altura: " + calcularAltura(raiz));
        System.out.println("Nodos operadores: " + contarOperadores(raiz));
        System.out.println("Nodos operandos: " + contarOperandos(raiz));

        sc.close();
    }

    public static int calcularAltura(NodoExpresion nodo) {

        if (nodo == null) {
            return 0;
        }

        int alturaIzq = calcularAltura(nodo.izq);
        int alturaDer = calcularAltura(nodo.der);

        return 1 + Math.max(alturaIzq, alturaDer);
    }

    public static int contarOperadores(NodoExpresion nodo) {

        if (nodo == null) {
            return 0;
        }

        int actual = nodo.esOperador() ? 1 : 0;

        return actual
                + contarOperadores(nodo.izq)
                + contarOperadores(nodo.der);
    }

    public static int contarOperandos(NodoExpresion nodo) {

        if (nodo == null) {
            return 0;
        }

        int actual = nodo.esOperador() ? 0 : 1;

        return actual
                + contarOperandos(nodo.izq)
                + contarOperandos(nodo.der);
    }
}


