package com.mycompany.arbolesexpresion;

public class Recorridos {

    // PREORDEN -> notación PREFIJA
    public static void preorden(NodoExpresion nodo, StringBuilder sb) {
        if (nodo == null) return;

        sb.append(nodo.valor).append(" ");

        preorden(nodo.izq, sb);
        preorden(nodo.der, sb);
    }

    // INORDEN -> notación INFIJA
    public static void inorden(NodoExpresion nodo, StringBuilder sb) {
        if (nodo == null) return;

        boolean esOp = nodo.esOperador();

        if (esOp) sb.append("(");

        inorden(nodo.izq, sb);

        sb.append(nodo.valor);

        inorden(nodo.der, sb);

        if (esOp) sb.append(")");
    }

    // POSTORDEN -> notación POSFIJA
    public static void postorden(NodoExpresion nodo, StringBuilder sb) {
        if (nodo == null) return;

        postorden(nodo.izq, sb);
        postorden(nodo.der, sb);

        sb.append(nodo.valor).append(" ");
    }
}


